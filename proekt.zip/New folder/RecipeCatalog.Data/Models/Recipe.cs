using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RecipeCatalog.Data.Models
{
    /// <summary>
    /// Represents a recipe in the catalog.
    /// </summary>
    public class Recipe
    {
        public Recipe()
        {
            RecipeIngredients = new HashSet<RecipeIngredient>();
            RecipeCategories = new HashSet<RecipeCategory>();
            Comments = new HashSet<Comment>();
        }

        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Заглавието е задължително.")]
        [StringLength(200, MinimumLength = 3, ErrorMessage = "Заглавието трябва да е между 3 и 200 символа.")]
        public string Title { get; set; } = string.Empty;

        [Required(ErrorMessage = "Описанието е задължително.")]
        [StringLength(2000, ErrorMessage = "Описанието не може да надвишава 2000 символа.")]
        public string Description { get; set; } = string.Empty;

        [Required(ErrorMessage = "Инструкциите са задължителни.")]
        public string Instructions { get; set; } = string.Empty;

        [Range(1, 480, ErrorMessage = "Времето за приготвяне трябва да е между 1 и 480 минути.")]
        public int PrepTimeMinutes { get; set; }

        [Range(0, 720, ErrorMessage = "Времето за готвене трябва да е между 0 и 720 минути.")]
        public int CookTimeMinutes { get; set; }

        [Range(1, 100, ErrorMessage = "Броят порции трябва да е между 1 и 100.")]
        public int Servings { get; set; }

        public string? ImageUrl { get; set; }

        public DifficultyLevel Difficulty { get; set; }

        public DateTime CreatedOn { get; set; } = DateTime.UtcNow;

        public DateTime? UpdatedOn { get; set; }

        public bool IsApproved { get; set; } = false;

        // Foreign key to the user who created the recipe
        public string AuthorId { get; set; } = string.Empty;

        [ForeignKey(nameof(AuthorId))]
        public virtual ApplicationUser Author { get; set; } = null!;

        // Many-to-many with Ingredient
        public virtual ICollection<RecipeIngredient> RecipeIngredients { get; set; }

        // Many-to-many with Category
        public virtual ICollection<RecipeCategory> RecipeCategories { get; set; }

        // One-to-many comments
        public virtual ICollection<Comment> Comments { get; set; }
    }

    /// <summary>
    /// Difficulty levels for recipes.
    /// </summary>
    public enum DifficultyLevel
    {
        Лесна = 1,
        Средна = 2,
        Трудна = 3
    }
}
