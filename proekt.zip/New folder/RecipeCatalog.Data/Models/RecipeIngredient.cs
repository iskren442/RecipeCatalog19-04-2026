using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RecipeCatalog.Data.Models
{
    /// <summary>
    /// Join entity for the many-to-many relationship between Recipe and Ingredient.
    /// Stores additional data such as quantity.
    /// </summary>
    public class RecipeIngredient
    {
        public int RecipeId { get; set; }

        [ForeignKey(nameof(RecipeId))]
        public virtual Recipe Recipe { get; set; } = null!;

        public int IngredientId { get; set; }

        [ForeignKey(nameof(IngredientId))]
        public virtual Ingredient Ingredient { get; set; } = null!;

        [Required(ErrorMessage = "Количеството е задължително.")]
        [StringLength(50)]
        public string Quantity { get; set; } = string.Empty;
    }
}
