using System.ComponentModel.DataAnnotations;

namespace RecipeCatalog.Data.Models
{
    /// <summary>
    /// Represents a category for grouping recipes.
    /// </summary>
    public class Category
    {
        public Category()
        {
            RecipeCategories = new HashSet<RecipeCategory>();
        }

        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Името на категорията е задължително.")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "Името трябва да е между 2 и 100 символа.")]
        public string Name { get; set; } = string.Empty;

        [StringLength(500)]
        public string? Description { get; set; }

        public string? ImageUrl { get; set; }

        // Many-to-many with Recipe
        public virtual ICollection<RecipeCategory> RecipeCategories { get; set; }
    }
}
