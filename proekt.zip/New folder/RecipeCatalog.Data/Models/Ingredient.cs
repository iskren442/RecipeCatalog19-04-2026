using System.ComponentModel.DataAnnotations;

namespace RecipeCatalog.Data.Models
{
    /// <summary>
    /// Represents an ingredient that can be used in multiple recipes.
    /// </summary>
    public class Ingredient
    {
        public Ingredient()
        {
            RecipeIngredients = new HashSet<RecipeIngredient>();
        }

        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Името на съставката е задължително.")]
        [StringLength(150, MinimumLength = 2, ErrorMessage = "Името трябва да е между 2 и 150 символа.")]
        public string Name { get; set; } = string.Empty;

        [StringLength(50)]
        public string? Unit { get; set; }

        // Many-to-many with Recipe via RecipeIngredient
        public virtual ICollection<RecipeIngredient> RecipeIngredients { get; set; }
    }
}
