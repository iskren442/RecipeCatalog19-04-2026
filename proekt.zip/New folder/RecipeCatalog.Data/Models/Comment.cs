using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RecipeCatalog.Data.Models
{
    /// <summary>
    /// Represents a user comment on a recipe.
    /// </summary>
    public class Comment
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Съдържанието на коментара е задължително.")]
        [StringLength(1000, MinimumLength = 3, ErrorMessage = "Коментарът трябва да е между 3 и 1000 символа.")]
        public string Content { get; set; } = string.Empty;

        public DateTime CreatedOn { get; set; } = DateTime.UtcNow;

        public int RecipeId { get; set; }

        [ForeignKey(nameof(RecipeId))]
        public virtual Recipe Recipe { get; set; } = null!;

        public string AuthorId { get; set; } = string.Empty;

        [ForeignKey(nameof(AuthorId))]
        public virtual ApplicationUser Author { get; set; } = null!;
    }
}
