using System.ComponentModel.DataAnnotations.Schema;

namespace RecipeCatalog.Data.Models
{
    /// <summary>
    /// Join entity for the many-to-many relationship between Recipe and Category.
    /// </summary>
    public class RecipeCategory
    {
        public int RecipeId { get; set; }

        [ForeignKey(nameof(RecipeId))]
        public virtual Recipe Recipe { get; set; } = null!;

        public int CategoryId { get; set; }

        [ForeignKey(nameof(CategoryId))]
        public virtual Category Category { get; set; } = null!;
    }
}
