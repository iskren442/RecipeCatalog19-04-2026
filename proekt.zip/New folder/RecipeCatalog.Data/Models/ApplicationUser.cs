using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace RecipeCatalog.Data.Models
{
    /// <summary>
    /// Extended application user with additional profile fields.
    /// </summary>
    public class ApplicationUser : IdentityUser
    {
        public ApplicationUser()
        {
            Recipes = new HashSet<Recipe>();
            Comments = new HashSet<Comment>();
        }

        [StringLength(100)]
        public string? FirstName { get; set; }

        [StringLength(100)]
        public string? LastName { get; set; }

        public string? AvatarUrl { get; set; }

        public DateTime RegisteredOn { get; set; } = DateTime.UtcNow;

        public virtual ICollection<Recipe> Recipes { get; set; }

        public virtual ICollection<Comment> Comments { get; set; }
    }
}
