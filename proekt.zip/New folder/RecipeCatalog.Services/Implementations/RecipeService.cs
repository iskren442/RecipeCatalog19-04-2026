using Microsoft.EntityFrameworkCore;
using RecipeCatalog.Data;
using RecipeCatalog.Data.Models;
using RecipeCatalog.Services.DTOs;
using RecipeCatalog.Services.Interfaces;

namespace RecipeCatalog.Services.Implementations
{
    /// <summary>
    /// Provides business logic for recipe CRUD operations and related functionality.
    /// </summary>
    public class RecipeService : IRecipeService
    {
        private readonly ApplicationDbContext _context;

        public RecipeService(ApplicationDbContext context)
        {
            _context = context;
        }

        /// <inheritdoc/>
        public async Task<IEnumerable<RecipeListDto>> GetAllAsync(string? search = null, int? categoryId = null)
        {
            var query = _context.Recipes
                .Where(r => r.IsApproved)
                .Include(r => r.Author)
                .Include(r => r.RecipeCategories)
                    .ThenInclude(rc => rc.Category)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                query = query.Where(r =>
                    r.Title.Contains(search) ||
                    r.Description.Contains(search));
            }

            if (categoryId.HasValue)
            {
                query = query.Where(r =>
                    r.RecipeCategories.Any(rc => rc.CategoryId == categoryId.Value));
            }

            var list = await query
                .OrderByDescending(r => r.CreatedOn)
                .ToListAsync();

            return list.Select(r => MapToListDto(r));
        }

        /// <inheritdoc/>
        public async Task<RecipeDetailDto?> GetByIdAsync(int id)
        {
            var recipe = await _context.Recipes
                .Include(r => r.Author)
                .Include(r => r.RecipeCategories).ThenInclude(rc => rc.Category)
                .Include(r => r.RecipeIngredients).ThenInclude(ri => ri.Ingredient)
                .Include(r => r.Comments).ThenInclude(c => c.Author)
                .FirstOrDefaultAsync(r => r.Id == id);

            if (recipe == null) return null;

            return new RecipeDetailDto
            {
                Id = recipe.Id,
                Title = recipe.Title,
                Description = recipe.Description,
                Instructions = recipe.Instructions,
                ImageUrl = recipe.ImageUrl,
                PrepTimeMinutes = recipe.PrepTimeMinutes,
                CookTimeMinutes = recipe.CookTimeMinutes,
                Servings = recipe.Servings,
                Difficulty = recipe.Difficulty,
                AuthorName = recipe.Author?.UserName ?? "Неизвестен",
                CreatedOn = recipe.CreatedOn,
                Categories = recipe.RecipeCategories.Select(rc => rc.Category.Name).ToList(),
                Ingredients = recipe.RecipeIngredients.Select(ri => new RecipeIngredientDto
                {
                    Name = ri.Ingredient.Name,
                    Quantity = ri.Quantity,
                    Unit = ri.Ingredient.Unit
                }).ToList(),
                Comments = recipe.Comments
                    .OrderByDescending(c => c.CreatedOn)
                    .Select(c => new CommentDto
                    {
                        Id = c.Id,
                        Content = c.Content,
                        AuthorName = c.Author?.UserName ?? "Неизвестен",
                        CreatedOn = c.CreatedOn
                    }).ToList()
            };
        }

        /// <inheritdoc/>
        public async Task<RecipeFormDto?> GetFormDtoAsync(int id)
        {
            var recipe = await _context.Recipes
                .Include(r => r.RecipeCategories)
                .Include(r => r.RecipeIngredients).ThenInclude(ri => ri.Ingredient)
                .FirstOrDefaultAsync(r => r.Id == id);

            if (recipe == null) return null;

            return new RecipeFormDto
            {
                Id = recipe.Id,
                Title = recipe.Title,
                Description = recipe.Description,
                Instructions = recipe.Instructions,
                ImageUrl = recipe.ImageUrl,
                PrepTimeMinutes = recipe.PrepTimeMinutes,
                CookTimeMinutes = recipe.CookTimeMinutes,
                Servings = recipe.Servings,
                Difficulty = recipe.Difficulty,
                SelectedCategoryIds = recipe.RecipeCategories.Select(rc => rc.CategoryId).ToList(),
                Ingredients = recipe.RecipeIngredients.Select(ri => new RecipeIngredientFormDto
                {
                    IngredientId = ri.IngredientId,
                    IngredientName = ri.Ingredient.Name,
                    Quantity = ri.Quantity
                }).ToList()
            };
        }

        /// <inheritdoc/>
        public async Task<int> CreateAsync(RecipeFormDto dto, string authorId)
        {
            var recipe = new Recipe
            {
                Title = dto.Title,
                Description = dto.Description,
                Instructions = dto.Instructions,
                ImageUrl = dto.ImageUrl,
                PrepTimeMinutes = dto.PrepTimeMinutes,
                CookTimeMinutes = dto.CookTimeMinutes,
                Servings = dto.Servings,
                Difficulty = dto.Difficulty,
                AuthorId = authorId,
                CreatedOn = DateTime.UtcNow,
                IsApproved = false
            };

            // Add category relationships
            foreach (var catId in dto.SelectedCategoryIds)
            {
                recipe.RecipeCategories.Add(new RecipeCategory { CategoryId = catId });
            }

            // Add ingredient relationships
            foreach (var ing in dto.Ingredients.Where(i => i.IngredientId > 0))
            {
                recipe.RecipeIngredients.Add(new RecipeIngredient
                {
                    IngredientId = ing.IngredientId,
                    Quantity = ing.Quantity
                });
            }

            _context.Recipes.Add(recipe);
            await _context.SaveChangesAsync();
            return recipe.Id;
        }

        /// <inheritdoc/>
        public async Task UpdateAsync(RecipeFormDto dto)
        {
            var recipe = await _context.Recipes
                .Include(r => r.RecipeCategories)
                .Include(r => r.RecipeIngredients)
                .FirstOrDefaultAsync(r => r.Id == dto.Id);

            if (recipe == null) return;

            recipe.Title = dto.Title;
            recipe.Description = dto.Description;
            recipe.Instructions = dto.Instructions;
            recipe.ImageUrl = dto.ImageUrl;
            recipe.PrepTimeMinutes = dto.PrepTimeMinutes;
            recipe.CookTimeMinutes = dto.CookTimeMinutes;
            recipe.Servings = dto.Servings;
            recipe.Difficulty = dto.Difficulty;
            recipe.UpdatedOn = DateTime.UtcNow;

            // Update categories
            _context.RecipeCategories.RemoveRange(recipe.RecipeCategories);
            foreach (var catId in dto.SelectedCategoryIds)
            {
                recipe.RecipeCategories.Add(new RecipeCategory { CategoryId = catId });
            }

            // Update ingredients
            _context.RecipeIngredients.RemoveRange(recipe.RecipeIngredients);
            foreach (var ing in dto.Ingredients.Where(i => i.IngredientId > 0))
            {
                recipe.RecipeIngredients.Add(new RecipeIngredient
                {
                    IngredientId = ing.IngredientId,
                    Quantity = ing.Quantity
                });
            }

            await _context.SaveChangesAsync();
        }

        /// <inheritdoc/>
        public async Task DeleteAsync(int id)
        {
            var recipe = await _context.Recipes.FindAsync(id);
            if (recipe != null)
            {
                _context.Recipes.Remove(recipe);
                await _context.SaveChangesAsync();
            }
        }

        /// <inheritdoc/>
        public async Task<IEnumerable<RecipeListDto>> GetPendingAsync()
        {
            var list = await _context.Recipes
                .Where(r => !r.IsApproved)
                .Include(r => r.Author)
                .Include(r => r.RecipeCategories).ThenInclude(rc => rc.Category)
                .OrderBy(r => r.CreatedOn)
                .ToListAsync();

            return list.Select(r => MapToListDto(r));
        }

        /// <inheritdoc/>
        public async Task ApproveAsync(int id)
        {
            var recipe = await _context.Recipes.FindAsync(id);
            if (recipe != null)
            {
                recipe.IsApproved = true;
                await _context.SaveChangesAsync();
            }
        }

        /// <inheritdoc/>
        public async Task<bool> IsAuthorAsync(int recipeId, string userId)
        {
            return await _context.Recipes.AnyAsync(r => r.Id == recipeId && r.AuthorId == userId);
        }

        /// <inheritdoc/>
        public async Task AddCommentAsync(int recipeId, string content, string authorId)
        {
            var comment = new Comment
            {
                RecipeId = recipeId,
                Content = content,
                AuthorId = authorId,
                CreatedOn = DateTime.UtcNow
            };
            _context.Comments.Add(comment);
            await _context.SaveChangesAsync();
        }

        /// <inheritdoc/>
        public async Task DeleteCommentAsync(int commentId)
        {
            var comment = await _context.Comments.FindAsync(commentId);
            if (comment != null)
            {
                _context.Comments.Remove(comment);
                await _context.SaveChangesAsync();
            }
        }

        // Maps a Recipe entity to a RecipeListDto
        private static RecipeListDto MapToListDto(Recipe r) => new RecipeListDto
        {
            Id = r.Id,
            Title = r.Title,
            Description = r.Description,
            ImageUrl = r.ImageUrl,
            PrepTimeMinutes = r.PrepTimeMinutes,
            CookTimeMinutes = r.CookTimeMinutes,
            Servings = r.Servings,
            Difficulty = r.Difficulty,
            AuthorName = r.Author != null ? r.Author.UserName ?? "" : "",
            CreatedOn = r.CreatedOn,
            Categories = r.RecipeCategories.Select(rc => rc.Category.Name).ToList()
        };
    }
}
