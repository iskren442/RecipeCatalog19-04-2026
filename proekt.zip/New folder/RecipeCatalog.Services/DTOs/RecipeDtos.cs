using RecipeCatalog.Data.Models;
using System.ComponentModel.DataAnnotations;

namespace RecipeCatalog.Services.DTOs
{
    /// <summary>
    /// Data transfer object for displaying a recipe in a list.
    /// </summary>
    public class RecipeListDto
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string? ImageUrl { get; set; }
        public int PrepTimeMinutes { get; set; }
        public int CookTimeMinutes { get; set; }
        public int Servings { get; set; }
        public DifficultyLevel Difficulty { get; set; }
        public string AuthorName { get; set; } = string.Empty;
        public DateTime CreatedOn { get; set; }
        public List<string> Categories { get; set; } = new();
    }

    /// <summary>
    /// DTO for the full recipe detail view.
    /// </summary>
    public class RecipeDetailDto : RecipeListDto
    {
        public string Instructions { get; set; } = string.Empty;
        public List<RecipeIngredientDto> Ingredients { get; set; } = new();
        public List<CommentDto> Comments { get; set; } = new();
    }

    /// <summary>
    /// DTO for creating or editing a recipe.
    /// </summary>
    public class RecipeFormDto
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Заглавието е задължително.")]
        [StringLength(200, MinimumLength = 3)]
        [Display(Name = "Заглавие")]
        public string Title { get; set; } = string.Empty;

        [Required(ErrorMessage = "Описанието е задължително.")]
        [StringLength(2000)]
        [Display(Name = "Кратко описание")]
        public string Description { get; set; } = string.Empty;

        [Required(ErrorMessage = "Инструкциите са задължителни.")]
        [Display(Name = "Начин на приготвяне")]
        public string Instructions { get; set; } = string.Empty;

        [Range(1, 480)]
        [Display(Name = "Време за подготовка (мин)")]
        public int PrepTimeMinutes { get; set; }

        [Range(0, 720)]
        [Display(Name = "Време за готвене (мин)")]
        public int CookTimeMinutes { get; set; }

        [Range(1, 100)]
        [Display(Name = "Брой порции")]
        public int Servings { get; set; } = 4;

        [Display(Name = "URL на снимка")]
        public string? ImageUrl { get; set; }

        [Display(Name = "Трудност")]
        public DifficultyLevel Difficulty { get; set; } = DifficultyLevel.Средна;

        [Display(Name = "Категории")]
        public List<int> SelectedCategoryIds { get; set; } = new();

        public List<RecipeIngredientFormDto> Ingredients { get; set; } = new();
    }

    /// <summary>
    /// DTO for a recipe ingredient entry in the form.
    /// </summary>
    public class RecipeIngredientFormDto
    {
        public int IngredientId { get; set; }
        public string IngredientName { get; set; } = string.Empty;
        public string Quantity { get; set; } = string.Empty;
    }

    /// <summary>
    /// DTO for displaying an ingredient with its quantity in a recipe.
    /// </summary>
    public class RecipeIngredientDto
    {
        public string Name { get; set; } = string.Empty;
        public string Quantity { get; set; } = string.Empty;
        public string? Unit { get; set; }
    }

    /// <summary>
    /// DTO for displaying a comment.
    /// </summary>
    public class CommentDto
    {
        public int Id { get; set; }
        public string Content { get; set; } = string.Empty;
        public string AuthorName { get; set; } = string.Empty;
        public DateTime CreatedOn { get; set; }
    }
}
