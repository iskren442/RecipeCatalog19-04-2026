using RecipeCatalog.Data.Models;

namespace RecipeCatalog.Services.Interfaces
{
    /// <summary>
    /// Service interface for category management.
    /// </summary>
    public interface ICategoryService
    {
        Task<IEnumerable<Category>> GetAllAsync();
        Task<Category?> GetByIdAsync(int id);
        Task CreateAsync(Category category);
        Task UpdateAsync(Category category);
        Task DeleteAsync(int id);
    }
}
