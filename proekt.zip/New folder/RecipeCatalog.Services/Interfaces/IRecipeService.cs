using RecipeCatalog.Services.DTOs;

namespace RecipeCatalog.Services.Interfaces
{
    /// <summary>
    /// Service interface for recipe business logic operations.
    /// </summary>
    public interface IRecipeService
    {
        /// <summary>Gets all approved recipes with optional search/filter.</summary>
        Task<IEnumerable<RecipeListDto>> GetAllAsync(string? search = null, int? categoryId = null);

        /// <summary>Gets a single recipe with full details.</summary>
        Task<RecipeDetailDto?> GetByIdAsync(int id);

        /// <summary>Gets the form DTO for editing an existing recipe.</summary>
        Task<RecipeFormDto?> GetFormDtoAsync(int id);

        /// <summary>Creates a new recipe and returns its ID.</summary>
        Task<int> CreateAsync(RecipeFormDto dto, string authorId);

        /// <summary>Updates an existing recipe.</summary>
        Task UpdateAsync(RecipeFormDto dto);

        /// <summary>Deletes a recipe by ID.</summary>
        Task DeleteAsync(int id);

        /// <summary>Gets all recipes pending admin approval.</summary>
        Task<IEnumerable<RecipeListDto>> GetPendingAsync();

        /// <summary>Approves a recipe.</summary>
        Task ApproveAsync(int id);

        /// <summary>Checks if a user is the author of a recipe.</summary>
        Task<bool> IsAuthorAsync(int recipeId, string userId);

        /// <summary>Adds a comment to a recipe.</summary>
        Task AddCommentAsync(int recipeId, string content, string authorId);

        /// <summary>Deletes a comment.</summary>
        Task DeleteCommentAsync(int commentId);
    }
}
