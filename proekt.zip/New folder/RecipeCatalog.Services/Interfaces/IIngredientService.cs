using RecipeCatalog.Data.Models;

namespace RecipeCatalog.Services.Interfaces
{
    /// <summary>
    /// Service interface for ingredient management.
    /// </summary>
    public interface IIngredientService
    {
        Task<IEnumerable<Ingredient>> GetAllAsync();
        Task<Ingredient?> GetByIdAsync(int id);
        Task<int> CreateAsync(Ingredient ingredient);
        Task UpdateAsync(Ingredient ingredient);
        Task DeleteAsync(int id);
    }
}
