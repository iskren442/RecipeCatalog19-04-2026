using Microsoft.EntityFrameworkCore;
using RecipeCatalog.Data;
using RecipeCatalog.Data.Models;
using RecipeCatalog.Services.DTOs;
using RecipeCatalog.Services.Implementations;
using Xunit;

namespace RecipeCatalog.Tests
{
    /// <summary>
    /// Unit tests for the RecipeService class using an in-memory database.
    /// </summary>
    public class RecipeServiceTests
    {
        // Creates a fresh in-memory database for each test
        private static ApplicationDbContext CreateInMemoryContext(string dbName)
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: dbName)
                .Options;
            return new ApplicationDbContext(options);
        }

        // Seeds a test user and a test recipe into the context
        private static (ApplicationUser user, Recipe recipe) SeedData(ApplicationDbContext context)
        {
            var user = new ApplicationUser
            {
                Id = "user-1",
                UserName = "test@test.com",
                Email = "test@test.com"
            };
            context.Users.Add(user);

            var recipe = new Recipe
            {
                Id = 1,
                Title = "Тестова рецепта",
                Description = "Описание",
                Instructions = "Инструкции",
                PrepTimeMinutes = 10,
                CookTimeMinutes = 20,
                Servings = 4,
                Difficulty = DifficultyLevel.Лесна,
                AuthorId = user.Id,
                IsApproved = true
            };
            context.Recipes.Add(recipe);
            context.SaveChanges();
            return (user, recipe);
        }

        [Fact]
        public async Task GetAllAsync_ReturnsOnlyApprovedRecipes()
        {
            // Arrange
            using var context = CreateInMemoryContext(nameof(GetAllAsync_ReturnsOnlyApprovedRecipes));
            var (user, _) = SeedData(context);

            // Add an unapproved recipe
            context.Recipes.Add(new Recipe
            {
                Title = "Непотвърдена",
                Description = "desc",
                Instructions = "inst",
                PrepTimeMinutes = 5,
                CookTimeMinutes = 5,
                Servings = 2,
                AuthorId = user.Id,
                IsApproved = false
            });
            context.SaveChanges();

            var service = new RecipeService(context);

            // Act
            var results = await service.GetAllAsync();

            // Assert
            Assert.Single(results);
            Assert.Equal("Тестова рецепта", results.First().Title);
        }

        [Fact]
        public async Task GetAllAsync_WithSearchFilter_ReturnsMatchingRecipes()
        {
            // Arrange
            using var context = CreateInMemoryContext(nameof(GetAllAsync_WithSearchFilter_ReturnsMatchingRecipes));
            var (user, _) = SeedData(context);

            var service = new RecipeService(context);

            // Act - search term matches
            var results = await service.GetAllAsync(search: "Тестова");

            // Assert
            Assert.Single(results);

            // Act - search term does not match
            var empty = await service.GetAllAsync(search: "Несъществуваща");
            Assert.Empty(empty);
        }

        [Fact]
        public async Task CreateAsync_AddsRecipeWithPendingApproval()
        {
            // Arrange
            using var context = CreateInMemoryContext(nameof(CreateAsync_AddsRecipeWithPendingApproval));
            var user = new ApplicationUser { Id = "u1", UserName = "u@u.com", Email = "u@u.com" };
            context.Users.Add(user);
            context.SaveChanges();

            var service = new RecipeService(context);
            var dto = new RecipeFormDto
            {
                Title = "Нова рецепта",
                Description = "Описание",
                Instructions = "Стъпки",
                PrepTimeMinutes = 10,
                CookTimeMinutes = 15,
                Servings = 2,
                Difficulty = DifficultyLevel.Средна
            };

            // Act
            var id = await service.CreateAsync(dto, user.Id);

            // Assert
            var created = context.Recipes.Find(id);
            Assert.NotNull(created);
            Assert.Equal("Нова рецепта", created.Title);
            Assert.False(created.IsApproved); // New recipes need admin approval
        }

        [Fact]
        public async Task ApproveAsync_SetsIsApprovedToTrue()
        {
            // Arrange
            using var context = CreateInMemoryContext(nameof(ApproveAsync_SetsIsApprovedToTrue));
            var (_, recipe) = SeedData(context);
            recipe.IsApproved = false;
            context.SaveChanges();

            var service = new RecipeService(context);

            // Act
            await service.ApproveAsync(recipe.Id);

            // Assert
            var updated = context.Recipes.Find(recipe.Id);
            Assert.True(updated!.IsApproved);
        }

        [Fact]
        public async Task DeleteAsync_RemovesRecipeFromDatabase()
        {
            // Arrange
            using var context = CreateInMemoryContext(nameof(DeleteAsync_RemovesRecipeFromDatabase));
            var (_, recipe) = SeedData(context);
            var service = new RecipeService(context);

            // Act
            await service.DeleteAsync(recipe.Id);

            // Assert
            Assert.Null(context.Recipes.Find(recipe.Id));
        }

        [Fact]
        public async Task IsAuthorAsync_ReturnsTrueForCorrectUser()
        {
            // Arrange
            using var context = CreateInMemoryContext(nameof(IsAuthorAsync_ReturnsTrueForCorrectUser));
            var (user, recipe) = SeedData(context);
            var service = new RecipeService(context);

            // Act & Assert
            Assert.True(await service.IsAuthorAsync(recipe.Id, user.Id));
            Assert.False(await service.IsAuthorAsync(recipe.Id, "other-user"));
        }

        [Fact]
        public async Task GetPendingAsync_ReturnsOnlyUnapprovedRecipes()
        {
            // Arrange
            using var context = CreateInMemoryContext(nameof(GetPendingAsync_ReturnsOnlyUnapprovedRecipes));
            var (user, _) = SeedData(context); // seeded recipe is approved

            context.Recipes.Add(new Recipe
            {
                Title = "Чакаща рецепта",
                Description = "d",
                Instructions = "i",
                PrepTimeMinutes = 5,
                CookTimeMinutes = 5,
                Servings = 1,
                AuthorId = user.Id,
                IsApproved = false
            });
            context.SaveChanges();

            var service = new RecipeService(context);

            // Act
            var pending = await service.GetPendingAsync();

            // Assert
            Assert.Single(pending);
            Assert.Equal("Чакаща рецепта", pending.First().Title);
        }

        [Fact]
        public async Task AddCommentAsync_CreatesCommentForRecipe()
        {
            // Arrange
            using var context = CreateInMemoryContext(nameof(AddCommentAsync_CreatesCommentForRecipe));
            var (user, recipe) = SeedData(context);
            var service = new RecipeService(context);

            // Act
            await service.AddCommentAsync(recipe.Id, "Страхотна рецепта!", user.Id);

            // Assert
            var comment = context.Comments.FirstOrDefault(c => c.RecipeId == recipe.Id);
            Assert.NotNull(comment);
            Assert.Equal("Страхотна рецепта!", comment.Content);
        }
    }
}
