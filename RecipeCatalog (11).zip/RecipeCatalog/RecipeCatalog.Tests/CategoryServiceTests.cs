using Microsoft.EntityFrameworkCore;
using RecipeCatalog.Data;
using RecipeCatalog.Data.Models;
using RecipeCatalog.Services.Implementations;
using Xunit;

namespace RecipeCatalog.Tests
{
    /// <summary>
    /// Unit tests for CategoryService using an in-memory database.
    /// </summary>
    public class CategoryServiceTests
    {
        private static ApplicationDbContext CreateInMemoryContext(string dbName)
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(dbName)
                .Options;
            return new ApplicationDbContext(options);
        }

        [Fact]
        public async Task GetAllAsync_ReturnsAllCategories()
        {
            // Arrange
            using var context = CreateInMemoryContext(nameof(GetAllAsync_ReturnsAllCategories));
            context.Categories.AddRange(
                new Category { Id = 10, Name = "Супи" },
                new Category { Id = 11, Name = "Десерти" }
            );
            context.SaveChanges();

            var service = new CategoryService(context);

            // Act
            var result = await service.GetAllAsync();

            // Assert - seeded data + 2 added
            Assert.Equal(2, result.Count());
        }

        [Fact]
        public async Task CreateAsync_AddsNewCategory()
        {
            // Arrange
            using var context = CreateInMemoryContext(nameof(CreateAsync_AddsNewCategory));
            var service = new CategoryService(context);
            var category = new Category { Name = "Напитки", Description = "Сокове и смутита" };

            // Act
            await service.CreateAsync(category);

            // Assert
            Assert.Equal(1, context.Categories.Count());
            Assert.Equal("Напитки", context.Categories.First().Name);
        }

        [Fact]
        public async Task DeleteAsync_RemovesCategory()
        {
            // Arrange
            using var context = CreateInMemoryContext(nameof(DeleteAsync_RemovesCategory));
            var cat = new Category { Id = 5, Name = "За изтриване" };
            context.Categories.Add(cat);
            context.SaveChanges();

            var service = new CategoryService(context);

            // Act
            await service.DeleteAsync(5);

            // Assert
            Assert.Empty(context.Categories);
        }

        [Fact]
        public async Task GetByIdAsync_ReturnsCorrectCategory()
        {
            // Arrange
            using var context = CreateInMemoryContext(nameof(GetByIdAsync_ReturnsCorrectCategory));
            context.Categories.Add(new Category { Id = 3, Name = "Салати" });
            context.SaveChanges();

            var service = new CategoryService(context);

            // Act
            var result = await service.GetByIdAsync(3);

            // Assert
            Assert.NotNull(result);
            Assert.Equal("Салати", result.Name);
        }
    }
}
