using Microsoft.AspNetCore.Mvc;
using RecipeCatalog.Services.Interfaces;

namespace RecipeCatalog.Web.Controllers
{
    /// <summary>
    /// Handles the home/landing page of the application.
    /// </summary>
    public class HomeController : Controller
    {
        private readonly IRecipeService _recipeService;
        private readonly ICategoryService _categoryService;

        public HomeController(IRecipeService recipeService, ICategoryService categoryService)
        {
            _recipeService = recipeService;
            _categoryService = categoryService;
        }

        /// <summary>Displays the home page with latest recipes.</summary>
        public async Task<IActionResult> Index()
        {
            var recipes = await _recipeService.GetAllAsync();
            var categories = await _categoryService.GetAllAsync();

            ViewBag.Categories = categories;
            return View(recipes.Take(6));
        }

        public IActionResult Privacy() => View();

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error() => View();
    }
}
