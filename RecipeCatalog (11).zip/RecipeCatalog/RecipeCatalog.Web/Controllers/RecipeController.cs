using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using RecipeCatalog.Data.Models;
using RecipeCatalog.Services.DTOs;
using RecipeCatalog.Services.Interfaces;

namespace RecipeCatalog.Web.Controllers
{
    /// <summary>
    /// Обработва всички CRUD операции за рецепти и разглеждане.
    /// </summary>
    public class RecipeController : Controller
    {
        private readonly IRecipeService _recipeService;
        private readonly ICategoryService _categoryService;
        private readonly IIngredientService _ingredientService;
        private readonly UserManager<ApplicationUser> _userManager;

        public RecipeController(
            IRecipeService recipeService,
            ICategoryService categoryService,
            IIngredientService ingredientService,
            UserManager<ApplicationUser> userManager)
        {
            _recipeService = recipeService;
            _categoryService = categoryService;
            _ingredientService = ingredientService;
            _userManager = userManager;
        }

        /// <summary>Показва всички одобрени рецепти с търсене и филтър по категория.</summary>
        [HttpGet]
        public async Task<IActionResult> Index(string? search, int? categoryId)
        {
            var recipes = await _recipeService.GetAllAsync(search, categoryId);
            var categories = await _categoryService.GetAllAsync();

            ViewBag.Categories = new SelectList(categories, "Id", "Name", categoryId);
            ViewBag.Search = search;
            ViewBag.SelectedCategory = categoryId;

            return View(recipes);
        }

        /// <summary>Показва пълни детайли за една рецепта.</summary>
        [HttpGet]
        public async Task<IActionResult> Details(int id)
        {
            var recipe = await _recipeService.GetByIdAsync(id);
            if (recipe == null) return NotFound();
            return View(recipe);
        }

        /// <summary>Показва формата за създаване на нова рецепта.</summary>
        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            await PopulateViewBagsAsync();
            return View(new RecipeFormDto());
        }

        /// <summary>
        /// Обработва формата за създаване.
        /// Ако е натиснат "Нов ред" — добавя празна съставка и връща формата.
        /// Ако е натиснат "Премахни" — премахва съставката по индекс.
        /// Ако е натиснат "Добави рецепта" — записва рецептата в базата.
        /// </summary>
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(RecipeFormDto dto,
            string? addIngredient, int? removeIngredient, string? submitRecipe)
        {
            // Бутон "+ Нов ред" — добавя нов празен ред за съставка
            if (addIngredient != null)
            {
                dto.Ingredients.Add(new RecipeIngredientFormDto());
                await PopulateViewBagsAsync();
                ModelState.Clear();
                return View(dto);
            }

            // Бутон "Премахни" — изтрива реда по индекс
            if (removeIngredient.HasValue)
            {
                dto.Ingredients.RemoveAt(removeIngredient.Value);
                await PopulateViewBagsAsync();
                ModelState.Clear();
                return View(dto);
            }

            // Бутон "Добави рецепта" — записва в базата
            if (!ModelState.IsValid)
            {
                await PopulateViewBagsAsync();
                return View(dto);
            }

            var userId = _userManager.GetUserId(User)!;
            var id = await _recipeService.CreateAsync(dto, userId);

            TempData["Success"] = "Рецептата беше добавена успешно и изчаква одобрение.";
            return RedirectToAction(nameof(Details), new { id });
        }

        /// <summary>Показва формата за редактиране на рецепта.</summary>
        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var dto = await _recipeService.GetFormDtoAsync(id);
            if (dto == null) return NotFound();

            var userId = _userManager.GetUserId(User)!;
            if (!await _recipeService.IsAuthorAsync(id, userId) && !User.IsInRole("Admin"))
                return Forbid();

            await PopulateViewBagsAsync();
            return View(dto);
        }

        /// <summary>
        /// Обработва формата за редактиране.
        /// Същата логика за добавяне/премахване на съставки като при Create.
        /// </summary>
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(RecipeFormDto dto,
            string? addIngredient, int? removeIngredient, string? submitRecipe)
        {
            // Бутон "+ Нов ред"
            if (addIngredient != null)
            {
                dto.Ingredients.Add(new RecipeIngredientFormDto());
                await PopulateViewBagsAsync();
                ModelState.Clear();
                return View(dto);
            }

            // Бутон "Премахни"
            if (removeIngredient.HasValue)
            {
                dto.Ingredients.RemoveAt(removeIngredient.Value);
                await PopulateViewBagsAsync();
                ModelState.Clear();
                return View(dto);
            }

            // Бутон "Запази промените"
            var userId = _userManager.GetUserId(User)!;
            if (!await _recipeService.IsAuthorAsync(dto.Id, userId) && !User.IsInRole("Admin"))
                return Forbid();

            if (!ModelState.IsValid)
            {
                await PopulateViewBagsAsync();
                return View(dto);
            }

            await _recipeService.UpdateAsync(dto);
            TempData["Success"] = "Рецептата беше обновена успешно.";
            return RedirectToAction(nameof(Details), new { id = dto.Id });
        }

        /// <summary>Изтрива рецепта. Само авторът или администратор могат да изтриват.</summary>
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var userId = _userManager.GetUserId(User)!;
            if (!await _recipeService.IsAuthorAsync(id, userId) && !User.IsInRole("Admin"))
                return Forbid();

            await _recipeService.DeleteAsync(id);
            TempData["Success"] = "Рецептата беше изтрита успешно.";
            return RedirectToAction(nameof(Index));
        }

        /// <summary>Добавя коментар към рецепта.</summary>
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddComment(int recipeId, string content)
        {
            if (!string.IsNullOrWhiteSpace(content))
            {
                var userId = _userManager.GetUserId(User)!;
                await _recipeService.AddCommentAsync(recipeId, content, userId);
            }
            return RedirectToAction(nameof(Details), new { id = recipeId });
        }

        /// <summary>Изтрива коментар. Само администратор.</summary>
        [Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteComment(int commentId, int recipeId)
        {
            await _recipeService.DeleteCommentAsync(commentId);
            return RedirectToAction(nameof(Details), new { id = recipeId });
        }

        // Зарежда ViewBag с категории и съставки за формата
        private async Task PopulateViewBagsAsync()
        {
            var categories = await _categoryService.GetAllAsync();
            var ingredients = await _ingredientService.GetAllAsync();
            ViewBag.Categories = new MultiSelectList(categories, "Id", "Name");
            ViewBag.Ingredients = new SelectList(ingredients, "Id", "Name");
        }
    }
}
