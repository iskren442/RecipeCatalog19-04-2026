using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RecipeCatalog.Data.Models;
using RecipeCatalog.Services.Interfaces;

namespace RecipeCatalog.Web.Controllers
{
    /// <summary>
    /// Admin panel controller - accessible only by users with the "Admin" role.
    /// </summary>
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {
        private readonly IRecipeService _recipeService;
        private readonly ICategoryService _categoryService;
        private readonly IIngredientService _ingredientService;

        public AdminController(
            IRecipeService recipeService,
            ICategoryService categoryService,
            IIngredientService ingredientService)
        {
            _recipeService = recipeService;
            _categoryService = categoryService;
            _ingredientService = ingredientService;
        }

        /// <summary>Admin dashboard showing pending recipes.</summary>
        public async Task<IActionResult> Index()
        {
            var pending = await _recipeService.GetPendingAsync();
            return View(pending);
        }

        /// <summary>Approves a pending recipe.</summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ApproveRecipe(int id)
        {
            await _recipeService.ApproveAsync(id);
            TempData["Success"] = "Рецептата беше одобрена.";
            return RedirectToAction(nameof(Index));
        }

        // ---- Category Management ----

        public async Task<IActionResult> Categories()
            => View(await _categoryService.GetAllAsync());

        [HttpGet]
        public IActionResult CreateCategory() => View(new Category());

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateCategory(Category category)
        {
            if (!ModelState.IsValid) return View(category);
            await _categoryService.CreateAsync(category);
            TempData["Success"] = "Категорията беше създадена.";
            return RedirectToAction(nameof(Categories));
        }

        [HttpGet]
        public async Task<IActionResult> EditCategory(int id)
        {
            var cat = await _categoryService.GetByIdAsync(id);
            if (cat == null) return NotFound();
            return View(cat);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditCategory(Category category)
        {
            if (!ModelState.IsValid) return View(category);
            await _categoryService.UpdateAsync(category);
            TempData["Success"] = "Категорията беше обновена.";
            return RedirectToAction(nameof(Categories));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            await _categoryService.DeleteAsync(id);
            TempData["Success"] = "Категорията беше изтрита.";
            return RedirectToAction(nameof(Categories));
        }

        // ---- Ingredient Management ----

        public async Task<IActionResult> Ingredients()
            => View(await _ingredientService.GetAllAsync());

        [HttpGet]
        public IActionResult CreateIngredient() => View(new Ingredient());

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateIngredient(Ingredient ingredient)
        {
            if (!ModelState.IsValid) return View(ingredient);
            await _ingredientService.CreateAsync(ingredient);
            TempData["Success"] = "Съставката беше добавена.";
            return RedirectToAction(nameof(Ingredients));
        }

        [HttpGet]
        public async Task<IActionResult> EditIngredient(int id)
        {
            var ing = await _ingredientService.GetByIdAsync(id);
            if (ing == null) return NotFound();
            return View(ing);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditIngredient(Ingredient ingredient)
        {
            if (!ModelState.IsValid) return View(ingredient);
            await _ingredientService.UpdateAsync(ingredient);
            TempData["Success"] = "Съставката беше обновена.";
            return RedirectToAction(nameof(Ingredients));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteIngredient(int id)
        {
            await _ingredientService.DeleteAsync(id);
            TempData["Success"] = "Съставката беше изтрита.";
            return RedirectToAction(nameof(Ingredients));
        }
    }
}
